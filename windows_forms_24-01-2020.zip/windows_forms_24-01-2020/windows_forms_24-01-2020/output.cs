﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace windows_forms_24_01_2020
{
    public partial class output : Form
    {
        public output()
        {
            InitializeComponent();
        }

        private void output_Load(object sender, EventArgs e)
        {
            Label l2 = new Label();

            l2.Text = "Login Sucessful";
            this.Controls.Add(l2);
        }

       

        private void btexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void exit1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
