﻿namespace windows_forms_24_01_2020
{
    partial class output
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btexit = new System.Windows.Forms.Button();
            this.exit1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btexit
            // 
            this.btexit.Location = new System.Drawing.Point(293, 145);
            this.btexit.Name = "btexit";
            this.btexit.Size = new System.Drawing.Size(75, 23);
            this.btexit.TabIndex = 0;
            this.btexit.Text = "Exit";
            this.btexit.UseVisualStyleBackColor = true;
            this.btexit.Click += new System.EventHandler(this.btexit_Click);
            // 
            // exit1
            // 
            this.exit1.Location = new System.Drawing.Point(548, 145);
            this.exit1.Name = "exit1";
            this.exit1.Size = new System.Drawing.Size(75, 23);
            this.exit1.TabIndex = 1;
            this.exit1.Text = "Pure Exit";
            this.exit1.UseVisualStyleBackColor = true;
            this.exit1.Click += new System.EventHandler(this.exit1_Click);
            // 
            // output
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exit1);
            this.Controls.Add(this.btexit);
            this.Name = "output";
            this.Text = "Output Window";
            this.Load += new System.EventHandler(this.output_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btexit;
        private System.Windows.Forms.Button exit1;
    }
}